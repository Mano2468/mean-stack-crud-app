export class EventManagement {
    name: string;
    email:string;
    phone: string;
    date: string;
    number_seat: number;
 }